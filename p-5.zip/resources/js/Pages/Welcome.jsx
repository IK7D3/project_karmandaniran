import React from 'react'

export const Welcome = () => {
    console.log('re');
  return (
    <div>Welcome</div>
  )
}
